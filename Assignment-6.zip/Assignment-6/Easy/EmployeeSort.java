import java.util.*;

class Employee {
    private String name;
    private int age;
    private double salary;

    public Employee(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public String getName() { return name; }
    public int getAge() { return age; }
    public double getSalary() { return salary; }

    @Override
    public String toString() {
        return "Employee{name='" + name + "', age=" + age + ", salary=" + salary + "}";
    }
}

public class EmployeeSort {
    public static void main(String[] args) {
        List<Employee> list = Arrays.asList(
            new Employee("Tanya", 25, 45000),
            new Employee("Amit", 30, 60000),
            new Employee("Rahul", 28, 55000)
        );

        System.out.println("Sorted by Name:");
        list.stream().sorted(Comparator.comparing(Employee::getName)).forEach(System.out::println);

        System.out.println("\nSorted by Age:");
        list.stream().sorted(Comparator.comparingInt(Employee::getAge)).forEach(System.out::println);

        System.out.println("\nSorted by Salary:");
        list.stream().sorted(Comparator.comparingDouble(Employee::getSalary)).forEach(System.out::println);
    }
}

